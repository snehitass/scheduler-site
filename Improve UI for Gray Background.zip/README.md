
  # Improve UI for Gray Background

  This is a code bundle for Improve UI for Gray Background. The original project is available at https://www.figma.com/design/b863ADpAeJ6n5DgyFzhS2F/Improve-UI-for-Gray-Background.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  