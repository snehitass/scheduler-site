import imgLogo2 from "figma:asset/8b02ce6fbd3019a3fa6031246214b8bf9def14b0.png";

function Group2() {
  return (
    <div className="absolute contents left-0 top-0">
      <div className="absolute bg-[47.65%_49.07%] bg-no-repeat bg-size-[141.58%_127.63%] h-[772.744px] left-0 rounded-[512px] top-0 w-[696.572px]" data-name="logo 2" style={{ backgroundImage: `url('${imgLogo2}')`, filter: 'contrast(1.2) brightness(1.1) saturate(1.1)' }} />
      <div className="absolute font-['Inter:Bold',_sans-serif] font-bold h-[180.407px] leading-[0] left-[457px] not-italic text-white text-[170px] top-[296px] w-[902.036px]">
        <p className="leading-[normal]">EquiShift</p>
      </div>
    </div>
  );
}

export default function Frame3() {
  return (
    <div className="relative size-full">
      <Group2 />
    </div>
  );
}