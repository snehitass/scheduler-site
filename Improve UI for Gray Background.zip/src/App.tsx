import Frame3 from "./imports/Frame3";

export default function App() {
  return (
    <div className="size-full bg-gray-100 flex items-center justify-center">
      <Frame3 />
    </div>
  );
}